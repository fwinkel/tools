/*================================================================================*/
/* Copyright (C) 2011, Don Milne.                                                 */
/* All rights reserved.                                                           */
/* See LICENSE.TXT for conditions on copying, distribution, modification and use. */
/*================================================================================*/

#define SOFTWARE_VERSION  0x0210
#define SOFTWARE_VERSION_STR  "2.10\000\000"
#define MAJOR_VER_DECIMAL 2
#define MINOR_VER_DECIMAL 10

#define COPYRIGHT_YEAR 2012
#define COPYRIGHT_STR  "Copyright � 2012, Don Milne\000\000"

