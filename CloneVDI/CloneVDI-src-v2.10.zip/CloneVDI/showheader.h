/*================================================================================*/
/* Copyright (C) 2009, Don Milne.                                                 */
/* All rights reserved.                                                           */
/* See LICENSE.TXT for conditions on copying, distribution, modification and use. */
/*================================================================================*/

#ifndef SHOWHEADER_H
#define SHOWHEADER_H

#include "vddr.h"

void ShowHeader_Show(HINSTANCE hInstRes, HWND hWndParent, HVDDR hVDI);

#endif

